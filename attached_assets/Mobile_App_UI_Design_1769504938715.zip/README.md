
  # Mobile App UI Design

  This is a code bundle for Mobile App UI Design. The original project is available at https://www.figma.com/design/56yks1ewwEl7CBSIhZGWPA/Mobile-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  